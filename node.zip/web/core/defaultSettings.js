import { THEME_COLOR_FALLBACKS } from "./themeTokens.js";

export const DEFAULT_GRID_SETTINGS = Object.freeze({
  enabled: true,
  snapNodesToGrid: false,
  gridStyle: "default",
  workflowRunAnimation: false,
  workflowRunStyle: "pulse-trail",
  spacing: 30,
  radius: 220,
  strength: 0.2,
  connectionInfluence: 0.2,
  nodeVisualFalloff: "soft",
  gridVisibility: 1,
  spring: 0.15,
  damping: 0.8,
  interactionSpringBoost: 1.7,
  interactionDamping: 0.74,
  maxOffset: 28,
  dotRadius: 1.4,
  dotAlpha: 0.84,
  dotColor: THEME_COLOR_FALLBACKS.dotColor,
  lineAlpha: 0.075,
  lineWidth: 1,
  lineColor: THEME_COLOR_FALLBACKS.lineColor,
  linkIdleColor: THEME_COLOR_FALLBACKS.linkIdleColor,
  linkRadius: 148,
  linkGlow: 1,
  nodeGlow: 1,
  colorGlow: "off",
  colorGlowStrength: 1,
  pointerRadius: 120,
  pointerStrength: 0.12,
  highlightColor: THEME_COLOR_FALLBACKS.highlightColor,
  accentColor: THEME_COLOR_FALLBACKS.accentColor,
  backgroundColorTop: THEME_COLOR_FALLBACKS.backgroundColorTop,
  backgroundColorBottom: THEME_COLOR_FALLBACKS.backgroundColorBottom,
  backgroundGlowColor: THEME_COLOR_FALLBACKS.backgroundGlowColor,
  backgroundAlpha: 0.22,
  nodePadding: 14,
  nodeCornerRadius: 20,
  nodeMaskPadding: 4,
  viewMarginCells: 3,
  performanceMode: "balanced",
});

export const PERFORMANCE_PROFILES = Object.freeze({
  eco: Object.freeze({
    maxNodes: 8,
    maxLinks: 16,
    viewportPadding: 180,
    idleFps: 10,
    activeFps: 18,
    viewMarginCells: 1.5,
    idleGridStep: 2,
    allowColorGlow: false,
    idleSkipBaseDots: true,
    idleSkipHighlightDots: true,
  }),
  balanced: Object.freeze({
    maxNodes: 18,
    maxLinks: 52,
    viewportPadding: 320,
    idleFps: 20,
    activeFps: 40,
    viewMarginCells: 3,
    idleGridStep: 1,
    allowColorGlow: true,
    idleSkipBaseDots: false,
    idleSkipHighlightDots: false,
  }),
  quality: Object.freeze({
    maxNodes: 32,
    maxLinks: 96,
    viewportPadding: 420,
    idleFps: 24,
    activeFps: 60,
    viewMarginCells: 3,
    idleGridStep: 1,
    allowColorGlow: true,
    idleSkipBaseDots: false,
    idleSkipHighlightDots: false,
  }),
});

export const NODE_VISUAL_FALLOFF_OPTIONS = Object.freeze([
  Object.freeze({ text: "Soft", value: "soft" }),
  Object.freeze({ text: "Edge Fade", value: "edge" }),
]);

export const WORKFLOW_RUN_STYLE_OPTIONS = Object.freeze([
  Object.freeze({ text: "Pulse Trail", value: "pulse-trail" }),
  Object.freeze({ text: "Comet Flow", value: "comet-flow" }),
  Object.freeze({ text: "Scan Sweep", value: "scan-sweep" }),
]);

export const COLOR_GLOW_MODE_OPTIONS = Object.freeze([
  Object.freeze({ text: "Off", value: "off" }),
  Object.freeze({ text: "Tint Cast", value: "tint-cast" }),
  Object.freeze({ text: "Bloom Glow", value: "bloom" }),
  Object.freeze({ text: "Neon Edge", value: "neon" }),
  Object.freeze({ text: "Aura Only", value: "aura" }),
]);

export { GRID_STYLE_OPTIONS } from "./gridStyles.js";

export function getPerformanceProfile(mode) {
  return PERFORMANCE_PROFILES[mode] ?? PERFORMANCE_PROFILES.balanced;
}

export function mergeSettings(base = DEFAULT_GRID_SETTINGS, patch = {}) {
  const merged = {
    ...base,
    ...patch,
  };

  return {
    ...merged,
    colorGlow: normalizeColorGlowMode(merged.colorGlow),
    colorGlowStrength: normalizeColorGlowStrength(merged.colorGlowStrength),
  };
}

export function normalizeColorGlowMode(value) {
  if (value === true) {
    return "bloom";
  }

  if (value === false || value == null || value === "") {
    return "off";
  }

  return COLOR_GLOW_MODE_OPTIONS.some((option) => option.value === value) ? value : DEFAULT_GRID_SETTINGS.colorGlow;
}

export function normalizeColorGlowStrength(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) {
    return DEFAULT_GRID_SETTINGS.colorGlowStrength;
  }

  return Math.min(Math.max(numeric, 0), 2);
}
